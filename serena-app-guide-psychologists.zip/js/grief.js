
function navigateTo(topic) {
    alert("Navigating to: " + topic); // Replace with actual navigation logic later
}

function goBack() {
    window.location.href = "menu.html";
}
