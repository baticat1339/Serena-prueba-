
function goBack() {
    window.location.href = "menu.html";
}
