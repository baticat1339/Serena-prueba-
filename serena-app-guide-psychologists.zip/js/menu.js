
function navigateTo(section) {
    window.location.href = section + ".html";
}
