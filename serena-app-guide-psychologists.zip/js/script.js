
function navigateToMenu() {
    window.location.href = "menu.html";
}
